Tanvi Kamble — Personal Portfolio

1. Extract this ZIP file.
2. Open index.html in your web browser to preview the website.
3. To publish it online, upload the files to a hosting service such as GitHub Pages.

Please review project descriptions and certification names to ensure they accurately reflect your completed work before publishing.
